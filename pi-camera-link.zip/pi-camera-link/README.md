# Pi Camera Link — Two-Way Phone ↔ Raspberry Pi Comms

Phone streams live camera to the Pi. Pi runs motion detection and sends
control signals back to the phone (audio + screen flash), plus fires the
phone's real LED torch through a Shortcuts automation.

```
   iPhone (Safari)                       Raspberry Pi
  ┌───────────────────┐    WebSocket    ┌─────────────────────┐
  │ Camera (getUserMedia) ────────────► │ Motion detection      │
  │ Speaker / screen  ◄──────────────── │ (OpenCV)               │
  └───────────────────┘                 │                        │
                                         │ ──► Pushcut webhook ──► Shortcuts ──► LED torch
                                         └─────────────────────┘
```

## 1. Set up the Pi

```bash
# On the Raspberry Pi
git clone <this folder> pi-camera-link   # or just copy the files over
cd pi-camera-link
pip install -r requirements.txt
```

Find the Pi's local IP address (needed in the next steps):

```bash
hostname -I
```

## 2. Set up real flash control (Shortcuts + Pushcut)

Safari on iOS can't access the camera torch directly from a webpage, so the
flash is triggered through a small automation chain instead:

1. Install **Pushcut** from the App Store (free tier is enough).
2. In Pushcut, go to **Notifications → New Notification** (e.g. name it "FlashOn").
3. Under **Actions**, add **Run Shortcut**, pointing at a Shortcut you create in
   the next step. Save.
4. Pushcut will show you a **webhook URL** for this notification — copy it.
5. In the **Shortcuts** app, create a new Shortcut (name it e.g. `FlashOn`) with:
   - `Set Flashlight → On`
   - `Wait 1 second` (or however long you want it lit)
   - `Set Flashlight → Off`
6. Back on the Pi, open `server.py` and paste your webhook URL in:
   ```python
   PUSHCUT_WEBHOOK_URL = "https://api.pushcut.io/xxxxxxx/notifications/FlashOn"
   ```

## 3. Run the server

```bash
python server.py
```

You'll see:
```
Starting server on http://0.0.0.0:5000
  Phone:   http://<pi-ip>:5000/phone
  Monitor: http://<pi-ip>:5000/monitor
```

## 4. Connect

- **On the iPhone:** open `http://<pi-ip>:5000/phone` in Safari, tap
  **Start Camera Link**, and allow camera access. Keep the tab open and the
  screen unlocked/awake (iOS suspends background tabs, which will pause the
  uplink).
- **On the laptop (optional):** open `http://<pi-ip>:5000/monitor` in any
  browser to watch the live relayed feed and a running motion event log.

## How the two-way link works

- **Uplink (phone → Pi):** the phone JS grabs camera frames every 200ms,
  encodes them as JPEG, and emits them over a WebSocket (`frame` event).
- **Downlink (Pi → phone):** when the Pi's OpenCV motion detector fires, it
  emits a `motion_signal` event back over the same WebSocket. The phone page
  reacts immediately with an audio tone and a full-screen white flash.
- **Downlink (Pi → phone, real LED):** in parallel, the Pi makes an HTTP POST
  to your Pushcut webhook URL, which runs your Shortcut and toggles the
  actual torch — independent of the WebSocket, so it still works even if the
  browser tab throttles JS timers in the background.

## Physical button trigger (optional)

You can wire a push button directly to the Pi to manually fire the same
alert (audio tone + screen flash on the phone) without waiting for motion:

- Wire one leg of the button to **GPIO 17** (physical pin 11)
- Wire the other leg to any **GND** pin (e.g. physical pin 9)

No resistor needed — `gpiozero`'s `Button` uses the Pi's internal pull-up.
As soon as the server starts, pressing the button sends the exact same
`motion_signal` event the phone reacts to, and fires Pushcut too (if
configured). Change `BUTTON_GPIO_PIN` in `server.py` if you wire it to a
different pin, and use BCM numbering (not physical pin numbers) when you do.

If you're testing `server.py` on your laptop instead of the Pi, the button
setup is skipped automatically (no `gpiozero`/GPIO hardware there) — the
rest of the server runs normally.

## Tuning

In `server.py`:
- `MOTION_MIN_AREA` — lower = more sensitive to small movements.
- `MOTION_COOLDOWN_SECONDS` — minimum gap between triggers (avoids spamming
  the flash/audio on continuous motion).
- `UPLINK_TARGET_SIZE` — resolution frames are resized to before detection;
  smaller = faster processing, useful in Pi Zero/3 class hardware.

In `templates/phone.html`:
- The `setInterval(..., 200)` uplink rate — raise this (e.g. to 300–500ms)
  if you're on a weak Wi-Fi link and frames start lagging.

## Notes

- This uses `async_mode="threading"` for Flask-SocketIO so no extra
  `eventlet`/`gevent` dependency is needed — fine for a single-phone demo.
  If you scale to multiple simultaneous phones, consider switching to
  `eventlet` for better concurrency.
- Everything runs over your local Wi-Fi network; no internet-facing ports
  are opened except the outbound call to Pushcut's webhook.
