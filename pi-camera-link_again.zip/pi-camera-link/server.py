"""
Raspberry Pi Two-Way Camera Link Server
=========================================
- Phone connects via Safari, streams camera frames UP to the Pi over a WebSocket.
- Pi runs motion detection on incoming frames.
- On motion:
    - Pushes an audio + screen-flash signal back DOWN to the phone (WebSocket).
    - Triggers a Pushcut webhook, which fires a Shortcuts action for the
      real LED torch (Safari can't control the torch directly, so this is
      the workaround: Pi -> Pushcut -> Shortcuts -> Set Flashlight).
- Optional /monitor page lets you watch the live relayed feed from a laptop browser.

Setup on the Pi:
  pip install -r requirements.txt
  # Edit PUSHCUT_WEBHOOK_URL below
  python server.py

Then:
  - On phone (Safari):  http://<pi-ip>:5000/phone
  - On laptop (browser): http://<pi-ip>:5000/monitor
"""

import base64
import time
import threading
from datetime import datetime

import cv2
import numpy as np
import requests
from flask import Flask, render_template
from flask_socketio import SocketIO

try:
    from gpiozero import Button
    GPIO_AVAILABLE = True
except ImportError:
    # Lets the server still run on a non-Pi machine (e.g. testing on your laptop)
    GPIO_AVAILABLE = False

# ---------------- Configuration ----------------
# Get this from Pushcut: Notification -> Create Notification -> Add "Run Shortcut"
# action pointing at a Shortcut that does "Set Flashlight -> On" (then maybe a delay
# and "Set Flashlight -> Off"). Copy the webhook URL Pushcut generates here.
# Leave as-is (containing "xxxxxxx") to skip the real-flash step entirely.
PUSHCUT_WEBHOOK_URL = "https://api.pushcut.io/xxxxxxx/notifications/FlashOn"

MOTION_MIN_AREA = 800            # lower = more sensitive
MOTION_COOLDOWN_SECONDS = 4.0    # min seconds between motion triggers
BUTTON_COOLDOWN_SECONDS = 1.0    # min seconds between button triggers
UPLINK_TARGET_SIZE = (640, 360)  # frame size used for detection + relay
BUTTON_GPIO_PIN = 17             # BCM numbering; button wired between this pin and GND
# -------------------------------------------------

app = Flask(__name__)
app.config["SECRET_KEY"] = "change-me"
socketio = SocketIO(app, async_mode="threading", max_http_buffer_size=10_000_000)

back_sub = cv2.createBackgroundSubtractorMOG2(history=500, varThreshold=40, detectShadows=False)

state = {
    "last_motion_trigger": 0.0,
    "last_button_trigger": 0.0,
    "frame_count": 0,
}


def broadcast_alert(source):
    """Send the audio + screen-flash signal to the phone, and (if configured)
    fire the real LED torch via Pushcut. Used by both motion detection and
    the physical button so they share one signal path."""
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] Alert triggered by {source} — signaling phone")
    socketio.emit("motion_signal", {"time": timestamp, "source": source})
    threading.Thread(target=trigger_pushcut, daemon=True).start()


def trigger_pushcut():
    """Fire the phone's LED torch via a Pushcut webhook. Runs off the main thread
    so a slow network call never blocks frame processing."""
    if not PUSHCUT_WEBHOOK_URL or "xxxxxxx" in PUSHCUT_WEBHOOK_URL:
        print("Pushcut webhook not configured — skipping flash trigger. Edit PUSHCUT_WEBHOOK_URL in server.py.")
        return
    try:
        resp = requests.post(PUSHCUT_WEBHOOK_URL, timeout=5)
        print(f"Pushcut triggered: HTTP {resp.status_code}")
    except requests.RequestException as e:
        print(f"Pushcut trigger failed: {e}")


@app.route("/phone")
def phone_page():
    return render_template("phone.html")


@app.route("/monitor")
def monitor_page():
    return render_template("monitor.html")


@socketio.on("frame")
def handle_frame(data):
    """Receives a base64-encoded JPEG frame from the phone (uplink)."""
    state["frame_count"] += 1

    try:
        _, encoded = data.split(",", 1) if "," in data else (None, data)
        img_bytes = base64.b64decode(encoded)
        np_arr = np.frombuffer(img_bytes, dtype=np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    except Exception as e:
        print(f"Frame decode error: {e}")
        return

    if frame is None:
        return

    frame = cv2.resize(frame, UPLINK_TARGET_SIZE)

    # --- Motion detection ---
    fg_mask = back_sub.apply(frame)
    fg_mask = cv2.medianBlur(fg_mask, 5)
    _, thresh = cv2.threshold(fg_mask, 200, 255, cv2.THRESH_BINARY)
    thresh = cv2.dilate(thresh, None, iterations=2)
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    motion_detected = False
    for c in contours:
        if cv2.contourArea(c) < MOTION_MIN_AREA:
            continue
        motion_detected = True
        x, y, w, h = cv2.boundingRect(c)
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 255), 2)

    # Ignore false positives while the background model is still learning
    if state["frame_count"] < 30:
        motion_detected = False

    label = "MOTION" if motion_detected else "clear"
    color = (0, 0, 255) if motion_detected else (0, 200, 0)
    cv2.putText(frame, label, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

    # Relay the annotated frame to any connected /monitor page(s)
    ok, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 70])
    if ok:
        out_b64 = "data:image/jpeg;base64," + base64.b64encode(buf).decode("ascii")
        socketio.emit("monitor_frame", out_b64)

    # --- Downlink control on motion ---
    now = time.time()
    if motion_detected and (now - state["last_motion_trigger"]) > MOTION_COOLDOWN_SECONDS:
        state["last_motion_trigger"] = now
        broadcast_alert(source="motion")


@socketio.on("connect")
def handle_connect():
    print("Client connected")


@socketio.on("disconnect")
def handle_disconnect():
    print("Client disconnected")


def handle_button_press():
    now = time.time()
    if (now - state["last_button_trigger"]) > BUTTON_COOLDOWN_SECONDS:
        state["last_button_trigger"] = now
        broadcast_alert(source="button")


def setup_button():
    if not GPIO_AVAILABLE:
        print("gpiozero not available — skipping button setup (fine if you're not on a Pi).")
        return
    button = Button(BUTTON_GPIO_PIN, bounce_time=0.2)  # internal pull-up, no resistor needed
    button.when_pressed = handle_button_press
    print(f"Button armed on GPIO {BUTTON_GPIO_PIN} (BCM) — press it to trigger an alert manually.")


if __name__ == "__main__":
    setup_button()

    import os
    cert_path, key_path = "cert.pem", "key.pem"
    use_ssl = os.path.exists(cert_path) and os.path.exists(key_path)

    if use_ssl:
        print("Starting server on https://0.0.0.0:5000 (SSL enabled)")
        print("  Phone:   https://<pi-ip>:5000/phone")
        print("  Monitor: https://<pi-ip>:5000/monitor")
        print("  NOTE: your phone will warn about an untrusted certificate the first")
        print("  time — tap 'Show Details' -> 'visit this website' to proceed. This")
        print("  is expected for a self-signed cert and is safe on your own network.")
        socketio.run(app, host="0.0.0.0", port=5000, ssl_context=(cert_path, key_path))
    else:
        print("WARNING: cert.pem/key.pem not found — running over plain HTTP.")
        print("iOS Safari will NOT allow camera access without HTTPS. Generate a cert with:")
        print('  openssl req -x509 -newkey rsa:2048 -nodes -keyout key.pem -out cert.pem -days 365 -subj "/CN=raspberrypi"')
        print("Starting server on http://0.0.0.0:5000")
        print("  Phone:   http://<pi-ip>:5000/phone")
        print("  Monitor: http://<pi-ip>:5000/monitor")
        socketio.run(app, host="0.0.0.0", port=5000)
